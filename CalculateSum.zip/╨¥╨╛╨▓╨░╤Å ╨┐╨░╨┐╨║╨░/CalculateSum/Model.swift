//
//  Model.swift
//  CalculateSum
//
//  Created by Yaroslav Shepilov on 12.12.2021.
//

import Foundation

final class Model {
    private var salary: Int?
    private var tax: Int?
    
    func setupSalary(value: String?) {
        guard let text = value, let salaryInt = Int(text) else {
            salary = nil
            return
        }
        salary = salaryInt
    }
    
    func setupTax(value: String?) {
        guard let text = value, let taxInt = Int(text) else {
            tax = nil
            return
        }
        tax = taxInt
    }
    func calculateResult() -> String? {
        guard let salaryUnwr = salary, let taxUnwr = tax else {
            return nil
        }
        
        let finalResult = salaryUnwr - (salaryUnwr * taxUnwr) / 100
        
        return String(format: "%i", finalResult)

    }
}
