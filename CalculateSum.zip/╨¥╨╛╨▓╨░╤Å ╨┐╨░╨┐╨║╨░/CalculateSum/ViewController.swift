//
//  ViewController.swift
//  CalculateSum
//
//  Created by Yaroslav Shepilov on 10.12.2021.
//

import UIKit

final class ViewController: UIViewController, UITextFieldDelegate {
    
    private let model = Model()
    
    @IBOutlet weak var enterSalary: UITextField!
    @IBOutlet weak var enterTax: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        enterSalary.delegate = self
        enterTax.delegate = self
        
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           textField.resignFirstResponder()
           return true
    }
    
    @IBAction func enterSalary(_ sender: UITextField) {
        model.setupSalary(value: sender.text)
    }
    
    @IBAction func enterTax(_ sender: UITextField) {
        model.setupTax(value: sender.text)
    }
    
    @IBAction func calculateButton(_ sender: Any) {
        guard let result = model.calculateResult() else {
            resultLabel.text = "Salary or tax are invalid"
            resultLabel.textColor = .red
            return
        }
        resultLabel.text = result
        resultLabel.textColor = .green
    }
}
